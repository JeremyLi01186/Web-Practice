var app = angular.module('Vidzy', ['ngResource', 'ngRoute']); //ngRoute is one of the built-in Angular modules for configuring routes.

app.config(['$routeProvider', '$locationProvider', function($routeProvider, $locationProvider){   //Now we depend on two modules: ngResource, for consuming RESTful APIs and ngRoute for routing.
    $routeProvider
        .when('/', {
            templateUrl: 'partials/home.html',
            controller: 'HomeCtrl'
        })
        .when('/add-video', {
            templateUrl: 'partials/video-form.html',
            controller: 'AddVideoCtrl'
        })
        .when('/video/:id', {
            templateUrl: 'partials/video-form.html',
            controller: 'EditVideoCtrl'
        })
        .when('/video/delete/:id', {
            templateUrl: 'partials/video-delete.html',
            controller: 'DeleteVideoCtrl'
        })
        .otherwise({
            redirectTo: '/'
        });

        $locationProvider.html5Mode( true );
}]);

app.controller('HomeCtrl', 
    function($scope, $resource, $location){

        var keyword = $location.search().keyword;
        var keywordGenre = $location.search().genKey;

        var Videos = $resource('/api/videos', {searchTitle:keyword,searchGenre:keywordGenre}); // cossuming API while passing a parameter
        Videos.query(function(videos){
            $scope.videos = videos;
        
        });

       
    });

app.controller('AddVideoCtrl',
    function($scope, $resource, $location){
        $scope.save = function(){
            var Videos = $resource('/api/videos');
            Videos.save($scope.video, function(){   //scope.video of vdieo-form html
                $location.path('/');
            });
        };
    });

app.controller('EditVideoCtrl', ['$scope', '$resource', '$location', '$routeParams',
    function($scope, $resource, $location, $routeParams){   
        var Videos = $resource('/api/videos/:id', { id: '@_id' }, {
            update: { method: 'PUT' }
        });

        Videos.get({ id: $routeParams.id }, function(video){
            $scope.video = video;
        });

        $scope.save = function(){
            Videos.update($scope.video, function(){
                $location.path('/');
            });
        }
    }]);


app.controller('DeleteVideoCtrl', ['$scope', '$resource', '$location', '$routeParams',
    function($scope, $resource, $location, $routeParams){
        var Videos = $resource('/api/videos/:id');

        Videos.get({ id: $routeParams.id }, function(video){
            $scope.video = video;
        })

        $scope.delete = function(){
            Videos.delete({ id: $routeParams.id }, function(video){
                $location.path('/');
            });
        }
    }]);