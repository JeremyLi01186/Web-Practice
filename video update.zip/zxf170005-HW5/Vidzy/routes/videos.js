var express = require('express');
var router = express.Router();

var monk = require('monk');
var db = monk('localhost:27017/vidzy');

/* GET home page. */
router.get('/', function(req, res) {
	var collection = db.get('videos');

	var searchTitle = req.query.searchTitle;
    var searchGenre= req.query.searchGenre;

    searchCriteria= {};
	
    if(searchTitle && searchGenre&& searchGenre!='all')
    {
        searchCriteria= {'title' : {'$regex' : searchTitle, '$options' : 'i'},'genre' : {'$regex' : searchGenre, '$options' : 'i'}};
    }

      if(searchTitle && searchGenre =='all')
    {
        searchCriteria= {'title' : {'$regex' : searchTitle, '$options' : 'i'}};
    }
    
     if(!searchTitle && searchGenre)
    {
        searchCriteria= {'genre' : {'$regex' : searchGenre, '$options' : 'i'}};

    }


     if(!searchTitle && searchGenre =='all')
    {
         searchCriteria= {};
    }


    collection.find(searchCriteria,function(err, videos){
        if(err) throw err;
        res.json(videos);
    });

  
});

router.get('/:id', function(req, res) {
	var collection = db.get('videos');
	collection.findOne({_id:req.params.id}, function(err, video){
		if(err) throw err;
		res.json(video);
	});
});

router.post('/', function(req, res){
    var collection = db.get('videos');
    collection.insert({
        title: req.body.title,
        genre: req.body.genre,
        description: req.body.desc
    }, function(err, video){
        if (err) throw err;
        res.json(video);
    });
});

router.put('/:id', function(req, res){
    var collection = db.get('videos');
    collection.update({
        _id: req.params.id
    },
    {
        title: req.body.title,
        genre: req.body.genre,
        description: req.body.desc
    }, function(err, video){
        if (err) throw err;

        res.json(video);
    });
});

router.delete('/:id', function(req, res){
    var collection = db.get('videos');
    collection.remove({ _id: req.params.id }, function(err, video){
        if (err) throw err;

        res.json(video);
    });
});

module.exports = router;
